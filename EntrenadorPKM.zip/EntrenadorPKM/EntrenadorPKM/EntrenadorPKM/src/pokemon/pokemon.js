class Pokemon {
    constructor(id, nombre, tipo, nivel, Num_Pokedex, entrenador, debilitado) {
        this.id = id;          
        this.nombre = nombre;  
        this.tipo = tipo;  
        this.Num_Pokedex = Num_Pokedex;    
        this.nivel = nivel;
        this.entrenador = entrenador;
        this.debilitado = debilitado;    
    }
}

export default Pokemon;
