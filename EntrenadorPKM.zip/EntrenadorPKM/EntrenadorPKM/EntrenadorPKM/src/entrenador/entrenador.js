class Entrenador {
    constructor(id, nombre, region, medallas, PKMCapturados, rango) {
        this.id = id;          
        this.nombre = nombre;  
        this.region = region;  
        this.medallas = medallas;
        this.PKMCapturados = PKMCapturados;
        this.rango = rango;
    }
}

export default Entrenador;